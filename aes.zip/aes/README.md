## Compilar (cmd)
```
g++ -std=c++17 -O2 -Wall -Wextra aes.cpp -o aes.exe
```

## Executar (cmd)
```
.\aes.exe 0f1571c947d9e8590cb7add6af7f6798 0123456789abcdeffedcba9876543210
```